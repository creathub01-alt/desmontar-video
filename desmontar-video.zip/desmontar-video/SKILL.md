---
name: desmontar-video
description: "Desmonta um vídeo que viralizou e refaz no mesmo estilo, com outro roteiro, em 2D feito em código. Baixa o vídeo e os outros do mesmo perfil, transcreve palavra por palavra, lê os quadros e mede a câmera, escreve a receita (a fórmula do roteiro, a câmera, o visual, os textos e o som), e depois refaz com a pessoa: o roteiro com as palavras dela, o personagem e o visual, a voz com o tempo de cada palavra, a cena em three.js renderizada pelo HyperFrames, o mapa de cenas, a conferência de cada quadro e a comparação lado a lado. Use quando a pessoa mandar o link de um vídeo e quiser entender como ele foi feito ou fazer um igual em estilo."
---

# Desmontar um vídeo viral e refazer em 20, com o Claude
.

Um vídeo que viraliza tem uma receita. Este skill acha a receita de um vídeo que a pessoa escolher e refaz no mesmo estilo, com o roteiro e o personagem dela. São 8 passos: 3 para desmontar e 5 para refazer. As ferramentas estão em `ferramentas/`, os guias de cada passo em `referencias/` e o modelo da cena 3D em `modelo/`.

O skill traz as ferramentas e o passo a passo. Ele não traz vídeo, voz, música nem personagem: tudo isso é da pessoa.

## Começar: o que perguntar

Numa mensagem só, pergunte:

1. O link do vídeo de referência (Instagram, TikTok, YouTube...). Se ela quiser, os links de outros vídeos do mesmo perfil.
2. O assunto do vídeo dela: igual ao da referência, ou outro (a receita serve para qualquer assunto).
3. A língua do vídeo dela.
4. A voz: a voz dela clonada na ElevenLabs, uma voz da ElevenLabs, ou ela mesma gravando (de graça).
5. O personagem: uma foto, um desenho, ou nenhum.

## O que precisa estar instalado

Confira e diga como resolver o que faltar (no Mac, com o Homebrew):

- **Python 3.10 ou mais novo** e os pacotes: `pip install opencv-python numpy` e um Whisper (`pip install mlx-whisper` no Mac com chip Apple, ou `pip install faster-whisper`). Com o `uv` instalado, dá para rodar sem instalar: `uv run --with opencv-python --with numpy python3 ...`.
- **ffmpeg** (`brew install ffmpeg`) e **yt-dlp** (`brew install yt-dlp`).
- **Node.js 22 ou mais novo** (`brew install node`), para o HyperFrames, que transforma a cena em vídeo. Ele roda com `npx`, sem instalar.
- **Uma pasta só para o vídeo.** Trabalhe só dentro dela.
- **Para a voz na ElevenLabs:** a chave num arquivo `.env` na pasta (`referencias/voz.md`). Nunca mostre a chave na tela nem escreva ela em outro arquivo.

## As regras

1. **O custo antes de gastar.** Antes de qualquer coisa paga (a voz na ElevenLabs), diga quantos caracteres vão ser usados e espere um ok. Baixar, transcrever, medir e renderizar é de graça, no computador.
2. **Um registro.** Mantenha `registro.md` na pasta: uma linha por passo, com o que foi feito, quanto tempo levou e quanto custou.
3. **Explique cada passo** em poucas linhas, para a pessoa conseguir fazer de novo sozinha.
4. **Não copie.** Da referência vem a receita: a estrutura, o ritmo, a câmera, o jeito de apresentar. O roteiro, o personagem e o visual são da pessoa. Não use as frases, o personagem nem os arquivos da referência no vídeo dela.
5. **Leia as imagens você mesmo.** Folha de quadros e mapa de cenas são para você abrir e olhar, não só para gerar.

## O passo a passo

Nos comandos, `$SKILL` é a pasta deste skill e a pasta atual é a pasta do vídeo.

### Desmontar

**1. Baixar e transcrever.**
1. `python3 $SKILL/ferramentas/baixar.py <link> [<outros links>] --pasta referencia`. Se o site pedir login, acrescente `--cookies chrome`. Sai `referencia/numeros.md` com os números de cada vídeo.
2. `python3 $SKILL/ferramentas/transcrever.py referencia --saida transcricoes`. Sai o texto e o tempo de cada palavra de cada vídeo.
3. Mostre a tabela de números e diga qual vídeo foi melhor e por quê.

**2. Ler cada quadro e medir a câmera.**
1. `python3 $SKILL/ferramentas/quadros.py referencia/<video>.mp4 --por-segundo 6 --saida quadros/6-por-segundo` e abra todas as folhas. Nos momentos importantes (uma peça entrando, um zoom), rode de novo com `--por-segundo 30 --de <início> --ate <fim>` para ver todos os quadros.
2. `python3 $SKILL/ferramentas/camera.py referencia/<video>.mp4 --saida camera`. Sai `camera/<video>.md`: cortes, movimentos, quanto tempo a câmera fica parada.
3. Anote como cada coisa aparece na tela: as peças, os textos, a legenda, os efeitos. `referencias/camera-e-textos.md` mostra o que olhar, com o que eu medi num vídeo de 6 milhões de visualizações.

**3. A receita.** Escreva `receita.md` seguindo `referencias/receita.md`: a fórmula do roteiro, a câmera, o visual, como cada peça entra, os textos na tela e o som, com os números medidos. Leia as transcrições de todos os vídeos: a fórmula é o que se repete em todos.

### Refazer

**4. O roteiro.** Siga `referencias/roteiro.md`: uma frase nova para cada frase da referência, na mesma ordem, cabendo no mesmo tempo, com as palavras da pessoa. Monte uma tabela com a referência de um lado e o novo do outro. Escreva `roteiro.txt` só com o que vai ser falado, uma frase por linha. Espere a aprovação: mudar depois da voz custa uma voz nova.

**5. O visual.** Siga `referencias/visual.md`. O personagem a partir da foto ou do desenho da pessoa, em 2D, em código. O estilo a partir de referências (Pinterest, canais de explicação). As peças funcionando de verdade, quando o vídeo explica uma máquina.

**6. A voz.**
1. ElevenLabs: `python3 $SKILL/ferramentas/voz.py roteiro.txt --voz <ID> --custo`, diga o número de caracteres, espere o ok, e rode sem `--custo`.
2. De graça: a pessoa grava lendo o roteiro (`voz/voz.wav`) e você roda `transcrever.py voz/voz.wav --saida voz`.
3. O tempo de cada palavra é o relógio do vídeo: tudo entra na palavra certa.

**7. Montar.**
1. `python3 $SKILL/ferramentas/montar.py --tempos voz/tempos.json --voz voz/voz.wav --cena cena` (com a voz gravada, use o `.json` do transcrever).
2. Edite `cena/js/cena.js`: troque o exemplo (um guarda-chuva) pelo cenário, pelo personagem e pelas peças do vídeo. Cada peça entra na palavra que fala dela (`Wd("palavra")`), a câmera segue a receita, a etiqueta aparece no começo da frase, a legenda é uma palavra por vez. `referencias/render.md` explica as regras da cena.
3. Para ver: `cd cena && npx --yes hyperframes@0.8.181 preview`. Para o vídeo: `cd cena && npx --yes hyperframes@0.8.181 render . --output ../video.mp4`.
4. O som: `referencias/som.md` (efeitos nas ações, uma música baixa, o volume final).

**8. Conferir.**
1. Antes de renderizar o vídeo inteiro: `python3 $SKILL/ferramentas/mapa.py --cena cena --referencia referencia/<video>.mp4 --tempos-ref transcricoes/<video>.json` e abra `mapa/mapa.html`. Mostre à pessoa e ajuste.
2. Depois do render: `python3 $SKILL/ferramentas/conferir.py video.mp4`, e `quadros.py video.mp4 --por-segundo 6` para olhar cada momento. O olho pega o que o programa não pega: uma parede tampando a câmera, uma fumaça que parece pedra.
3. `python3 $SKILL/ferramentas/lado_a_lado.py referencia/<video>.mp4 video.mp4 --saida lado-a-lado.mp4` para comparar.

No fim, mostre o `registro.md`: o que foi feito, o tempo e o valor final.
