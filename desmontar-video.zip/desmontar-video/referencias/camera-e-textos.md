# A câmera e os textos: o que eu medi num vídeo de 6 milhões de visualizações

Um vídeo de 2 minutos e 51 segundos explicando como um motor de carro funciona, peça por peça, em 3D. Medido em todos os 5.133 quadros. Serve de régua para comparar com a sua referência; a sua pode ser diferente.

## A câmera
- **13 cortes em 171 segundos.** Um trecho fica 86 segundos sem corte. Corta só quando muda de lugar (da rua para a oficina, do motor para o carro) ou para dividir a tela.
- **A câmera fica parada uns dois terços do tempo.** Parada não quer dizer morta: ela desliza devagar.
- **A cada 2 a 4 segundos, uma aproximação rápida**, de uns 14 quadros (meio segundo), com aceleração suave no começo e no fim, terminando na peça que o narrador está falando. Começa até 4 quadros depois da primeira palavra da frase.
- Aproximações e afastamentos aparecem em número parecido: a câmera "respira".
- Tela dividida (em cima e embaixo) para mostrar causa e efeito: o carro dando tranco em cima, o motor embaixo.

## Como cada peça entra
- **Voando até o lugar**, em arco, girando e assentando, em uns 8 quadros (as peças grandes, uns 14, passando um pouco do lugar e voltando).
- **Na palavra que fala dela** (no mesmo quadro, no máximo 5 quadros de diferença).
- Quando a peça ganha nome, ela **pisca** clara e escura, a cada 12 quadros, por 1 a 2 segundos.

## Os textos
- **Legenda: uma palavra por vez**, grande, branca com contorno escuro, um pouco abaixo do meio da tela.
- **A frase que dá nome a uma peça fica inteira amarela** na legenda. Depois, quando a peça é citada de novo, a legenda volta a ser branca.
- **A etiqueta com o nome aparece uns 10 quadros antes do nome ser falado**, no começo da frase ("Esse é o..."), ao lado da peça.
- Etiquetas e avisos aparecem crescendo em **3 quadros** e somem em 4.
- Tudo tem nome duas vezes (etiqueta e legenda): o vídeo funciona sem som.

## O som
- A voz na frente, sem parar (a maior pausa tem menos de 2 segundos), uns 197 palavras por minuto.
- Volume final perto de **-14 LUFS**, bem comprimido. Música baixa, efeitos nas ações (um zoom com "whoosh", uma explosão com uma batida grave).
