# O visual: o personagem, o estilo e as peças

## O personagem
- Uma foto sua, um desenho ou uma imagem do Pinterest servem de referência. O Claude monta em 3D com formas simples (caixas, esferas, cilindros) e deixa braços, pernas e cabeça mexendo.
- Formas simples com cantos arredondados ficam com cara de brinquedo e funcionam bem em vídeo vertical.
- O personagem aparece nos momentos de sentimento (cansado, confuso, feliz) e sai de cena quando a explicação é só da máquina.

## O estilo
- Junte referências no Pinterest (pesquise "low poly 3D", "isometric diorama", "cutaway engine", "cute 3D car") e nos canais de explicação em 3D do YouTube. Salve as imagens numa pasta e mostre ao Claude.
- Escolha poucas cores. Uma ideia que funciona: o cenário em tons apagados e as peças em cores fortes, cada família de peça com a sua cor.
- Luz: uma luz principal de um lado, uma mais fraca do outro e uma por trás contornando as peças.

## As peças
- Quando o vídeo explica uma máquina, faça as peças funcionarem de verdade: o que gira gira, o que sobe e desce sobe e desce, no ritmo certo. Quem assiste percebe.
- Mostre o que está dentro: vidro, corte, transparência.
- Cada peça precisa ser reconhecível pela silhueta, mesmo pequena na tela do celular.

## Não copie
Da referência vem o jeito de apresentar. O personagem, o cenário e as cores do seu vídeo são seus.
