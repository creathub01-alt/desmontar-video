# Skill desmontar-video: desmonte um vídeo viral e refaça no mesmo estilo

É o processo em que o Claude assiste um vídeo que viralizou quadro a quadro, entende como foi feito e refaz do zero, em código, com outro roteiro e outro personagem.

Você manda o link de um vídeo que deu certo, e o Claude faz com você, explicando cada passo:

1. Baixa o vídeo e os outros do mesmo perfil, e transcreve palavra por palavra.
2. Lê os quadros e mede a câmera: cortes, zooms, quanto tempo ela fica parada.
3. Escreve a receita: a fórmula do roteiro, a câmera, o visual, os textos e o som.
4. Escreve o seu roteiro, frase por frase, com as suas palavras.
5. Monta o seu personagem e o visual em 3D, em código.
6. Faz a voz, com o tempo de cada palavra.
7. Monta o vídeo: cada peça entra na palavra que fala dela.
8. Confere: o mapa de cenas, cada quadro do vídeo e a comparação lado a lado com a referência.

## O que você precisa

- **O Claude com acesso às pastas do seu computador:** o Claude Code, ou a aba Code do app do Claude.
- **No computador:** Python 3.10 ou mais novo, ffmpeg, yt-dlp e Node.js 22 ou mais novo. O Claude confere e diz como instalar o que faltar.
- **Para a voz:** uma conta na ElevenLabs (cobra por caractere: um vídeo de 3 minutos tem uns 2.500), ou a sua própria voz gravada, de graça.

Baixar, transcrever, medir a câmera, montar e renderizar é de graça: roda tudo no seu computador.

## O que você traz

O skill traz as ferramentas e o passo a passo. O resto é seu:

- **O vídeo de referência:** um que deu certo, no estilo que você quer.
- **A voz:** a sua, gravada ou clonada, ou uma da ElevenLabs.
- **O personagem:** uma foto sua, um desenho ou uma referência do Pinterest.
- **A música e os efeitos:** `referencias/som.md` mostra onde achar de graça.

## Como instalar

**No Claude Code:**

1. Copie a pasta `desmontar-video` para a pasta `.claude/skills` da sua pasta de usuário.
2. Abra uma sessão nova numa pasta vazia, só para o vídeo.
3. Peça: "quero entender como este vídeo foi feito e fazer um no mesmo estilo: <link>".

**No app do Claude:**

1. Em Configurações, Capacidades, envie o arquivo `.zip` do skill.
2. Use a aba Code, com uma pasta do seu computador aberta.

**Em outra IA:** cole o conteúdo do `SKILL.md` como instrução e mande as ferramentas junto. Ela precisa conseguir rodar comandos no seu computador.

## O que vem na pasta

- `SKILL.md`: o passo a passo que o Claude segue.
- `ferramentas/`: `baixar.py`, `transcrever.py`, `quadros.py`, `camera.py`, `voz.py`, `montar.py`, `mapa.py`, `conferir.py`, `lado_a_lado.py`.
- `modelo/`: a cena 3D de partida (three.js), com um exemplo de guarda-chuva montado em três partes. O Claude troca o exemplo pelo seu vídeo.
- `exemplo/roteiro.txt`: o roteiro do exemplo.
- `referencias/`: um guia por etapa (a receita, o roteiro, o visual, a voz, a câmera e os textos, o som, o render).

Para testar se está tudo instalado: `python3 ferramentas/montar.py --exemplo --cena cena-exemplo` e depois `cd cena-exemplo && npx --yes hyperframes@0.8.181 render . --output ../exemplo.mp4`. Sai um vídeo de 22 segundos do guarda-chuva sendo montado.
